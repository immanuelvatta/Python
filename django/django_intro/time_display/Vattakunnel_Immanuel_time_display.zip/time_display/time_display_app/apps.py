from django.apps import AppConfig


class TimeDisplayAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'time_display_app'
